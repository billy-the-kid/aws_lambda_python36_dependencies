from mpl_toolkits.axes_grid1.colorbar import (
    make_axes_kw_doc, colormap_kw_doc, colorbar_doc,
    CbarAxesLocator, ColorbarBase, Colorbar,
    make_axes, colorbar
)
